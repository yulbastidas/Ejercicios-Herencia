package EjercicioPrograma;

import java.util.Scanner;  


public class Nombre {
 protected String nombre;
 protected String primerApellido;
 protected String segundoApellido;

 
 public Nombre(String nombre, String primerApellido, String segundoApellido) {
     this.nombre = nombre;
     this.primerApellido = primerApellido;
     this.segundoApellido = segundoApellido;
 }

 
 public void leerNombre() {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Introduce el nombre: ");
     nombre = scanner.nextLine();
     System.out.print("Introduce el primer apellido: ");
     primerApellido = scanner.nextLine();
     System.out.print("Introduce el segundo apellido: ");
     segundoApellido = scanner.nextLine();
 }

 
 public void mostrar() {
     System.out.println("Nombre completo: " + nombre + " " + primerApellido + " " + segundoApellido);
 }
}
