
package EjercicioPrograma;
import java.util.Scanner;  


public class Direccion extends Nombre {
    private String calle;
    private String ciudad;
    private String provincia;
    private String codigoPostal;

    
    public Direccion(String nombre, String primerApellido, String segundoApellido,
                     String calle, String ciudad, String provincia, String codigoPostal) {
        super(nombre, primerApellido, segundoApellido);  
        this.calle = calle;
        this.ciudad = ciudad;
        this.provincia = provincia;
        this.codigoPostal = codigoPostal;
    }

    
    public void nuevaDireccion() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduce la calle: ");
        calle = scanner.nextLine();
        System.out.print("Introduce la ciudad: ");
        ciudad = scanner.nextLine();
        System.out.print("Introduce la provincia: ");
        provincia = scanner.nextLine();
        System.out.print("Introduce el código postal: ");
        codigoPostal = scanner.nextLine();
    }

    
    public void nuevoNombre() {
        super.leerNombre();  
    }

   
    @Override
    public void mostrar() {
        super.mostrar();  
        System.out.println("Calle: " + calle);
        System.out.println("Ciudad: " + ciudad);
        System.out.println("Provincia: " + provincia);
        System.out.println("Código postal: " + codigoPostal);
    }
}
