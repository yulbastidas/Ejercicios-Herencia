package EjercicioPrograma;

public class ProgramaDireccion {
    public static void main(String[] args) {
      
        Direccion direccion = new Direccion("", "", "", "", "", "", "");
        
        
        System.out.println("Introduce los datos del nombre:");
        direccion.nuevoNombre();
        
        System.out.println("\nIntroduce los datos de la dirección:");
        direccion.nuevaDireccion();
        
        
        System.out.println("\nDatos completos:");
        direccion.mostrar();
    }
}
