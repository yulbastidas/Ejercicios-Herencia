package EjercicioAnimal;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Ingrese el nombre del animal: ");
        String animalName = scanner.nextLine();
        Animal animal = new Animal(animalName);
        System.out.println(animal.toString());

        
        System.out.print("Ingrese el nombre del mamífero: ");
        String mammalName = scanner.nextLine();
        Mammal mammal = new Mammal(mammalName);
        System.out.println(mammal.toString());

        System.out.print("Ingrese el nombre del gato: ");
        String catName = scanner.nextLine();
        Cat cat = new Cat(catName);
        System.out.println(cat.toString());
        cat.greets();

        
        System.out.print("Ingrese el nombre del primer perro: ");
        String dogName1 = scanner.nextLine();
        Dog dog1 = new Dog(dogName1);
        System.out.println(dog1.toString());
        dog1.greets();

        System.out.print("Ingrese el nombre del segundo perro: ");
        String dogName2 = scanner.nextLine();
        Dog dog2 = new Dog(dogName2);
        System.out.println(dog2.toString());
        
        
        dog1.greets(dog2);

 }
}
