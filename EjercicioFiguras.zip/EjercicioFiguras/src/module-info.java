/**
 * 
 */
/**
 * 
 */
module EjercicioFiguras {
}