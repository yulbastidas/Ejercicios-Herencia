package EjercicioFiguras;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Ingrese el radio del círculo:");
        double radius = scanner.nextDouble();
        System.out.println("Ingrese el color del círculo:");
        String circleColor = scanner.next();
        System.out.println("¿Está lleno el círculo? (true/false):");
        boolean circleFilled = scanner.nextBoolean();
        Circle circle = new Circle(radius, circleColor, circleFilled);
        System.out.println(circle);
        System.out.println("Área del círculo: " + circle.getArea());
        System.out.println("Perímetro del círculo: " + circle.getPerimeter());

       
        System.out.println("Ingrese el ancho del rectángulo:");
        double width = scanner.nextDouble();
        System.out.println("Ingrese el largo del rectángulo:");
        double length = scanner.nextDouble();
        System.out.println("Ingrese el color del rectángulo:");
        String rectangleColor = scanner.next();
        System.out.println("¿Está lleno el rectángulo? (true/false):");
        boolean rectangleFilled = scanner.nextBoolean();
        Rectangle rectangle = new Rectangle(width, length, rectangleColor, rectangleFilled);
        System.out.println(rectangle);
        System.out.println("Área del rectángulo: " + rectangle.getArea());
        System.out.println("Perímetro del rectángulo: " + rectangle.getPerimeter());

        
        System.out.println("Ingrese el lado del cuadrado:");
        double side = scanner.nextDouble();
        System.out.println("Ingrese el color del cuadrado:");
        String squareColor = scanner.next();
        System.out.println("¿Está lleno el cuadrado? (true/false):");
        boolean squareFilled = scanner.nextBoolean();
        Square square = new Square(side, squareColor, squareFilled);
        System.out.println(square);
        System.out.println("Área del cuadrado: " + square.getArea());
        System.out.println("Perímetro del cuadrado: " + square.getPerimeter());

        
    }
}
