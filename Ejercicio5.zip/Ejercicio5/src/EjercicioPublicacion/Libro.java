package EjercicioPublicacion;

import java.util.Scanner;  


public class Libro extends Publicacion {
 private int numPaginas;
 private int anioPublicacion;

 @Override
 public void ingresarDatos() {
     super.ingresarDatos();
     Scanner scanner = new Scanner(System.in);
     System.out.print("Introduce el número de páginas: ");
     numPaginas = scanner.nextInt();
     System.out.print("Introduce el año de publicación: ");
     anioPublicacion = scanner.nextInt();
 }

 @Override
 public void mostrar() {
     super.mostrar();
     System.out.println("Número de páginas: " + numPaginas);
     System.out.println("Año de publicación: " + anioPublicacion);
 }
}
