package EjercicioPublicacion;

public class ProgramaLibro {
    public static void main(String[] args) {
        
        Libro libro = new Libro();
        
        System.out.println("Introduce los datos del libro:");
        libro.ingresarDatos();
        
        System.out.println("\nDatos del libro:");
        libro.mostrar();
    }
}
