package EjercicioPublicacion;

import java.util.Scanner;  


public class Publicacion {
 protected String titulo;
 protected float precio;

 
 public void ingresarDatos() {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Introduce el título: ");
     titulo = scanner.nextLine();
     System.out.print("Introduce el precio: ");
     precio = scanner.nextFloat();
 }


 public void mostrar() {
     System.out.println("Título: " + titulo);
     System.out.println("Precio: " + precio);
 }
}
