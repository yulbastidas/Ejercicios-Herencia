package EjercicioPublicacion;

import java.util.Scanner;  

public class Disco extends Publicacion {
 private float duracionMinutos;
 private int precioDisco;

 
 @Override
 public void ingresarDatos() {
     Scanner scanner = new Scanner(System.in);
     System.out.print("Introduce la duración en minutos: ");
     duracionMinutos = scanner.nextFloat();
     System.out.print("Introduce el precio del disco: ");
     precioDisco = scanner.nextInt();
 }


 @Override
 public void mostrar() {
     System.out.println("Duración en minutos: " + duracionMinutos);
     System.out.println("Precio del disco: " + precioDisco);
 }
}
