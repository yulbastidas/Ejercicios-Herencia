package EjercicioCirculos;

public class Circulo {
    protected double radio;

    
    public Circulo(double radio) {
        this.radio = radio;
    }

    
    public double area() {
        return Math.PI * Math.pow(radio, 2);
    }

    
    public double circunferencia() {
        return 2 * Math.PI * radio;
    }

    
    public void mostrar() {
        System.out.println("Radio: " + radio);
        System.out.println("Área del círculo: " + area());
        System.out.println("Circunferencia: " + circunferencia());
    }
}
