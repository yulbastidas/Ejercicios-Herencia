package EjercicioCirculos;

public class Cilindro extends Circulo {
    protected double altura;

  
    public Cilindro(double radio, double altura) {
        super(radio);  
        this.altura = altura;
    }

  
    public double areaCilindro() {
        return 2 * Math.PI * radio * altura + 2 * super.area();
    }

   
    public double volumen() {
        return super.area() * altura;
    }

    
    @Override
    public void mostrar() {
        super.mostrar();
        System.out.println("Altura del cilindro: " + altura);
        System.out.println("Área del cilindro: " + areaCilindro());
        System.out.println("Volumen del cilindro: " + volumen());
    }
}
