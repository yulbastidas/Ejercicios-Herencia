package EjercicioCirculos;

public class CilindroHueco extends Cilindro {
    private double radioInterno;

    
    public CilindroHueco(double radioExterno, double altura, double radioInterno) {
        super(radioExterno, altura);  
        this.radioInterno = radioInterno;
    }

   
    public double areaCilindroHueco() {
        return 2 * Math.PI * altura * (radio + radioInterno) + 2 * (super.area() - Math.PI * Math.pow(radioInterno, 2));
    }

    
    @Override
    public void mostrar() {
        super.mostrar();
        System.out.println("Radio interno del cilindro hueco: " + radioInterno);
        System.out.println("Área del cilindro hueco: " + areaCilindroHueco());
    }
}
