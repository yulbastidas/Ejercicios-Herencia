package EjercicioCirculos;

public class ProgramaGeometria {
    public static void main(String[] args) {
        InputHandler input = new InputHandler();
        
        
        double radioCirculo = input.leerRadio();
        Circulo circulo = new Circulo(radioCirculo);
        System.out.println("\nDatos del Círculo:");
        circulo.mostrar();
        
        
        double radioCilindro = input.leerRadio();
        double alturaCilindro = input.leerAltura();
        Cilindro cilindro = new Cilindro(radioCilindro, alturaCilindro);
        System.out.println("\nDatos del Cilindro:");
        cilindro.mostrar();
        
       
        double radioCilindroHueco = input.leerRadio();
        double alturaCilindroHueco = input.leerAltura();
        double radioInterno = input.leerRadioInterno();
        CilindroHueco cilindroHueco = new CilindroHueco(radioCilindroHueco, alturaCilindroHueco, radioInterno);
        System.out.println("\nDatos del Cilindro Hueco:");
        cilindroHueco.mostrar();
    }
}
