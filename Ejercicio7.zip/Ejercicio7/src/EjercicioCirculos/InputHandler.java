package EjercicioCirculos;

import java.util.Scanner;

public class InputHandler {
    private Scanner scanner;

    public InputHandler() {
        this.scanner = new Scanner(System.in);
    }

    
    public double leerRadio() {
        System.out.print("Introduce el radio: ");
        return scanner.nextDouble();
    }

   
    public double leerAltura() {
        System.out.print("Introduce la altura: ");
        return scanner.nextDouble();
    }

    
    public double leerRadioInterno() {
        System.out.print("Introduce el radio interno del cilindro hueco: ");
        return scanner.nextDouble();
    }
}
