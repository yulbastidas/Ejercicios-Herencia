
package EjercicioDos;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.println("Ingrese el nombre del estudiante:");
        String studentName = scanner.nextLine();
        System.out.println("Ingrese la dirección del estudiante:");
        String studentAddress = scanner.nextLine();
        System.out.println("Ingrese el programa del estudiante:");
        String program = scanner.nextLine();
        System.out.println("Ingrese el año del estudiante:");
        int year = scanner.nextInt();
        System.out.println("Ingrese la cuota del estudiante:");
        double fee = scanner.nextDouble();
        scanner.nextLine(); 

        Student student = new Student(studentName, studentAddress, program, year, fee);
        System.out.println("Estudiante creado: " + student);

       
        System.out.println("\nIngrese el nombre del personal:");
        String staffName = scanner.nextLine();
        System.out.println("Ingrese la dirección del personal:");
        String staffAddress = scanner.nextLine();
        System.out.println("Ingrese la escuela del personal:");
        String school = scanner.nextLine();
        System.out.println("Ingrese el pago del personal:");
        double pay = scanner.nextDouble();

        Staff staff = new Staff(staffName, staffAddress, school, pay);
        System.out.println("Personal creado: " + staff);

        
    }
}
