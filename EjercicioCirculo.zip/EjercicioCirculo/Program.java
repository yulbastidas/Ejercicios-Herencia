
package EjercicioCirculo;

import java.util.Scanner;

public class Program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        System.out.println("Ingrese el radio del círculo:");
        double radius = scanner.nextDouble();
        scanner.nextLine(); 

        System.out.println("Ingrese el color del círculo:");
        String color = scanner.nextLine();

 
        Circle circle = new Circle(radius, color);

        System.out.println("El círculo ha sido creado: " + circle);
        System.out.println("Área del círculo: " + circle.getArea());

       
        System.out.println("Ingrese la altura del cilindro:");
        double height = scanner.nextDouble();

     
        Cylinder cylinder = new Cylinder(radius, color, height);

        System.out.println("El cilindro ha sido creado: " + cylinder);
        System.out.println("Área de la base (círculo) del cilindro: " + cylinder.getArea());
        System.out.println("Volumen del cilindro: " + cylinder.getVolume());

       
    }
}
